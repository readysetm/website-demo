import React, { useState, useEffect } from 'react';
import { UserProfile, FitnessPlan } from './types';
import OnboardingForm from './components/OnboardingForm';
import PlanDisplay from './components/PlanDisplay';
import { generateFitnessPlan } from './services/geminiService';
import { Dumbbell, Sparkles } from 'lucide-react';

const App: React.FC = () => {
  // Initialize state from localStorage if available
  const [profile, setProfile] = useState<UserProfile | null>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('fitgenius_profile');
      try {
        return saved ? JSON.parse(saved) : null;
      } catch (e) {
        return null;
      }
    }
    return null;
  });

  const [plan, setPlan] = useState<FitnessPlan | null>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('fitgenius_plan');
      try {
        return saved ? JSON.parse(saved) : null;
      } catch (e) {
        return null;
      }
    }
    return null;
  });

  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Save plan changes to localStorage
  useEffect(() => {
    if (plan) {
      localStorage.setItem('fitgenius_plan', JSON.stringify(plan));
    }
  }, [plan]);

  // Save profile changes to localStorage
  useEffect(() => {
    if (profile) {
      localStorage.setItem('fitgenius_profile', JSON.stringify(profile));
    }
  }, [profile]);

  const handleProfileSubmit = async (userProfile: UserProfile) => {
    setProfile(userProfile);
    setIsLoading(true);
    setError(null);
    try {
      const generatedPlan = await generateFitnessPlan(userProfile);
      setPlan(generatedPlan);
    } catch (err) {
      console.error(err);
      setError("We encountered an issue connecting to our AI trainers. Please ensure your API key is configured correctly and try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleReset = () => {
    if (window.confirm("Are you sure you want to start over? This will clear your current generated plan.")) {
      setPlan(null);
      localStorage.removeItem('fitgenius_plan');
      // We keep the profile data so the form is pre-filled for convenience
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 pb-20">
      {/* Navigation Bar */}
      <nav className="bg-white border-b border-slate-200 px-6 py-4 sticky top-0 z-50">
        <div className="max-w-5xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center text-white">
              <Dumbbell className="w-5 h-5" />
            </div>
            <span className="text-xl font-bold text-slate-800 tracking-tight">FitGenius<span className="text-emerald-600">AI</span></span>
          </div>
          <div className="text-sm font-medium text-slate-500">
             v1.0
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="pt-8">
        {!plan && !isLoading && (
            <div className="text-center mb-10 px-4">
                <h1 className="text-4xl md:text-5xl font-bold text-slate-900 mb-4 tracking-tight">
                    Your Dream Body, <br className="hidden md:block"/>
                    <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-600 to-blue-600">Engineered by AI</span>
                </h1>
                <p className="text-lg text-slate-600 max-w-2xl mx-auto">
                    Stop guessing. Get a fully personalized workout routine and meal plan tailored exactly to your unique biology, goals, and lifestyle in seconds.
                </p>
            </div>
        )}

        {isLoading ? (
             <div className="flex flex-col items-center justify-center min-h-[50vh] px-4">
                <div className="relative w-24 h-24 mb-8">
                    <div className="absolute inset-0 border-4 border-slate-200 rounded-full"></div>
                    <div className="absolute inset-0 border-4 border-emerald-500 rounded-full border-t-transparent animate-spin"></div>
                    <Sparkles className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-emerald-500 w-8 h-8 animate-pulse" />
                </div>
                <h2 className="text-2xl font-bold text-slate-800 mb-2 text-center">Analysing your profile...</h2>
                <p className="text-slate-500 text-center max-w-md animate-pulse">
                    Our AI is calculating your metabolic rate, selecting optimal exercises for {profile?.goal}, and structuring your weekly schedule.
                </p>
             </div>
        ) : plan ? (
          <PlanDisplay plan={plan} onReset={handleReset} />
        ) : (
          <>
            <OnboardingForm onSubmit={handleProfileSubmit} isLoading={isLoading} />
            {error && (
                <div className="max-w-2xl mx-auto mt-6 p-4 bg-red-50 border border-red-200 text-red-700 rounded-xl text-center">
                    {error}
                </div>
            )}
          </>
        )}
      </main>
    </div>
  );
};

export default App;