import { GoogleGenAI, Type } from "@google/genai";
import { UserProfile, FitnessPlan } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateFitnessPlan = async (profile: UserProfile): Promise<FitnessPlan> => {
  const prompt = `
    Create a personalized 7-day workout routine and a representative daily meal plan for a user with the following profile:
    - Age: ${profile.age}
    - Gender: ${profile.gender}
    - Height: ${profile.height}cm
    - Weight: ${profile.weight}kg
    - Activity Level: ${profile.activityLevel}
    - Primary Goal: ${profile.goal}
    - Dietary Restrictions/Preferences: ${profile.dietaryRestrictions || "None"}
    - Available Equipment: ${profile.equipment || "Bodyweight only"}

    The plan should be practical, science-based, and specifically tailored to the goal. 
    For the nutrition section, provide a detailed example day that fits their calculated macro targets.
  `;

  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash",
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          overview: {
            type: Type.STRING,
            description: "A brief encouraging summary of the plan and why it works for this user.",
          },
          tips: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "5 actionable tips for success."
          },
          weeklySchedule: {
            type: Type.ARRAY,
            description: "7 days of workouts (or rest days)",
            items: {
              type: Type.OBJECT,
              properties: {
                dayName: { type: Type.STRING, description: "e.g., Monday or Day 1" },
                focus: { type: Type.STRING, description: "e.g., Upper Body Power, Rest, Cardio" },
                durationMinutes: { type: Type.INTEGER },
                exercises: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      name: { type: Type.STRING },
                      sets: { type: Type.INTEGER },
                      reps: { type: Type.STRING, description: "e.g., '8-12' or 'Until failure'" },
                      notes: { type: Type.STRING, description: "Form cues or tempo instructions" }
                    },
                    required: ["name", "sets", "reps", "notes"]
                  }
                }
              },
              required: ["dayName", "focus", "durationMinutes", "exercises"]
            }
          },
          nutritionPlan: {
            type: Type.ARRAY,
            description: "A representative day of eating",
            items: {
              type: Type.OBJECT,
              properties: {
                dayName: { type: Type.STRING, description: "e.g., Example Full Day of Eating" },
                totalCalories: { type: Type.INTEGER },
                meals: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      type: { type: Type.STRING, description: "Breakfast, Lunch, etc." },
                      name: { type: Type.STRING, description: "Recipe name" },
                      calories: { type: Type.INTEGER },
                      protein: { type: Type.INTEGER },
                      carbs: { type: Type.INTEGER },
                      fats: { type: Type.INTEGER },
                      ingredients: {
                        type: Type.ARRAY,
                        items: { type: Type.STRING }
                      }
                    },
                    required: ["type", "name", "calories", "protein", "carbs", "fats", "ingredients"]
                  }
                }
              },
              required: ["dayName", "totalCalories", "meals"]
            }
          }
        },
        required: ["overview", "weeklySchedule", "nutritionPlan", "tips"]
      }
    }
  });

  if (!response.text) {
    throw new Error("Failed to generate plan");
  }

  return JSON.parse(response.text) as FitnessPlan;
};
