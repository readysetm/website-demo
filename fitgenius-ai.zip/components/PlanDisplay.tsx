import React, { useState } from 'react';
import { FitnessPlan, WorkoutDay, DietDay } from '../types';
import { 
  Dumbbell, 
  Utensils, 
  Clock, 
  Flame, 
  CheckCircle2, 
  ChevronRight, 
  Info,
  CalendarDays
} from 'lucide-react';

interface PlanDisplayProps {
  plan: FitnessPlan;
  onReset: () => void;
}

const PlanDisplay: React.FC<PlanDisplayProps> = ({ plan, onReset }) => {
  const [activeTab, setActiveTab] = useState<'workout' | 'nutrition'>('workout');

  return (
    <div className="max-w-5xl mx-auto p-4 md:p-8 animate-fade-in">
      {/* Header Section */}
      <div className="bg-white rounded-2xl shadow-xl p-8 mb-8 border border-slate-100 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-100 rounded-full mix-blend-multiply filter blur-3xl opacity-50 -translate-y-1/2 translate-x-1/2"></div>
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-blue-100 rounded-full mix-blend-multiply filter blur-3xl opacity-50 translate-y-1/2 -translate-x-1/2"></div>
        
        <div className="relative z-10">
            <div className="flex justify-between items-start mb-6">
                <div>
                    <h2 className="text-3xl font-bold text-slate-800 mb-2">Your Personalized Blueprint</h2>
                    <p className="text-slate-600 max-w-2xl">{plan.overview}</p>
                </div>
                <button 
                    onClick={onReset}
                    className="text-sm text-slate-500 hover:text-emerald-600 underline"
                >
                    Start Over
                </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                 <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                    <h3 className="font-semibold text-slate-800 flex items-center gap-2 mb-3">
                        <Info className="w-4 h-4 text-emerald-500" />
                        Coach's Tips
                    </h3>
                    <ul className="space-y-2">
                        {plan.tips.slice(0, 3).map((tip, idx) => (
                            <li key={idx} className="flex items-start gap-2 text-sm text-slate-600">
                                <CheckCircle2 className="w-4 h-4 text-emerald-500 mt-0.5 flex-shrink-0" />
                                {tip}
                            </li>
                        ))}
                    </ul>
                 </div>
                 <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 flex flex-col justify-center items-center text-center">
                    <p className="text-slate-500 text-sm mb-1">Estimated Daily Calorie Target</p>
                    <p className="text-4xl font-bold text-slate-800">
                        {plan.nutritionPlan[0]?.totalCalories || 2000}
                        <span className="text-base font-normal text-slate-500 ml-1">kcal</span>
                    </p>
                 </div>
            </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-4 mb-6">
        <button
          onClick={() => setActiveTab('workout')}
          className={`flex-1 py-4 rounded-xl font-semibold flex items-center justify-center gap-2 transition-all duration-200 ${
            activeTab === 'workout'
              ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-200'
              : 'bg-white text-slate-500 hover:bg-slate-50 border border-slate-200'
          }`}
        >
          <Dumbbell className="w-5 h-5" />
          Workout Schedule
        </button>
        <button
          onClick={() => setActiveTab('nutrition')}
          className={`flex-1 py-4 rounded-xl font-semibold flex items-center justify-center gap-2 transition-all duration-200 ${
            activeTab === 'nutrition'
              ? 'bg-blue-600 text-white shadow-lg shadow-blue-200'
              : 'bg-white text-slate-500 hover:bg-slate-50 border border-slate-200'
          }`}
        >
          <Utensils className="w-5 h-5" />
          Nutrition Plan
        </button>
      </div>

      {/* Content Area */}
      <div className="space-y-6">
        {activeTab === 'workout' ? (
          <div className="grid grid-cols-1 gap-6">
            {plan.weeklySchedule.map((day, index) => (
              <WorkoutCard key={index} day={day} />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-6">
            {plan.nutritionPlan.map((day, index) => (
              <NutritionCard key={index} day={day} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

const WorkoutCard: React.FC<{ day: WorkoutDay }> = ({ day }) => {
    const isRest = day.focus.toLowerCase().includes('rest');

    return (
        <div className={`bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden ${isRest ? 'opacity-80' : ''}`}>
            <div className={`p-4 border-b border-slate-100 flex justify-between items-center ${isRest ? 'bg-slate-50' : 'bg-white'}`}>
                <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center ${isRest ? 'bg-slate-200 text-slate-500' : 'bg-emerald-100 text-emerald-600'}`}>
                        {isRest ? <CalendarDays className="w-5 h-5" /> : <Dumbbell className="w-5 h-5" />}
                    </div>
                    <div>
                        <h3 className="font-bold text-slate-800">{day.dayName}</h3>
                        <p className="text-sm text-emerald-600 font-medium">{day.focus}</p>
                    </div>
                </div>
                {!isRest && (
                    <div className="flex items-center gap-1 text-slate-500 text-sm bg-slate-100 px-3 py-1 rounded-full">
                        <Clock className="w-4 h-4" />
                        {day.durationMinutes} min
                    </div>
                )}
            </div>
            
            {!isRest && (
                <div className="p-4">
                    <div className="overflow-x-auto">
                        <table className="w-full text-sm text-left">
                            <thead className="text-xs text-slate-500 uppercase bg-slate-50">
                                <tr>
                                    <th className="px-4 py-2 rounded-l-lg">Exercise</th>
                                    <th className="px-4 py-2">Sets</th>
                                    <th className="px-4 py-2">Reps</th>
                                    <th className="px-4 py-2 rounded-r-lg">Notes</th>
                                </tr>
                            </thead>
                            <tbody>
                                {day.exercises.map((ex, idx) => (
                                    <tr key={idx} className="border-b border-slate-50 last:border-0 hover:bg-slate-50 transition-colors">
                                        <td className="px-4 py-3 font-medium text-slate-800">{ex.name}</td>
                                        <td className="px-4 py-3 text-slate-600">{ex.sets}</td>
                                        <td className="px-4 py-3 text-slate-600">{ex.reps}</td>
                                        <td className="px-4 py-3 text-slate-500 italic text-xs">{ex.notes}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            )}
            {isRest && (
                <div className="p-6 text-center text-slate-500 italic">
                    Active recovery. Light walking or stretching recommended.
                </div>
            )}
        </div>
    )
}

const NutritionCard: React.FC<{ day: DietDay }> = ({ day }) => {
    return (
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
            <div className="p-4 bg-blue-50 border-b border-blue-100 flex justify-between items-center">
                <div>
                    <h3 className="font-bold text-slate-800">{day.dayName}</h3>
                    <p className="text-sm text-blue-600">Sample Meal Plan</p>
                </div>
                <div className="bg-white px-3 py-1 rounded-full shadow-sm">
                    <span className="font-bold text-slate-800">{day.totalCalories}</span> 
                    <span className="text-xs text-slate-500 ml-1">kcal</span>
                </div>
            </div>
            <div className="divide-y divide-slate-100">
                {day.meals.map((meal, idx) => (
                    <div key={idx} className="p-4 hover:bg-slate-50 transition-colors">
                        <div className="flex justify-between items-start mb-2">
                            <div>
                                <span className="text-xs font-bold uppercase tracking-wider text-slate-400 block mb-1">{meal.type}</span>
                                <h4 className="font-semibold text-slate-800 text-lg">{meal.name}</h4>
                            </div>
                            <div className="text-right">
                                <span className="font-bold text-slate-700">{meal.calories}</span>
                                <span className="text-xs text-slate-400 block">kcal</span>
                            </div>
                        </div>
                        
                        <div className="flex gap-4 mb-3 text-xs">
                            <div className="flex items-center gap-1 text-red-500 bg-red-50 px-2 py-0.5 rounded">
                                <span className="font-bold">{meal.protein}g</span> Protein
                            </div>
                            <div className="flex items-center gap-1 text-amber-500 bg-amber-50 px-2 py-0.5 rounded">
                                <span className="font-bold">{meal.carbs}g</span> Carbs
                            </div>
                            <div className="flex items-center gap-1 text-yellow-600 bg-yellow-50 px-2 py-0.5 rounded">
                                <span className="font-bold">{meal.fats}g</span> Fats
                            </div>
                        </div>

                        <div className="text-sm text-slate-600 bg-slate-50 p-3 rounded-lg border border-slate-100">
                            <span className="font-medium text-slate-700 mr-2">Ingredients:</span>
                            {meal.ingredients.join(', ')}
                        </div>
                    </div>
                ))}
            </div>
        </div>
    )
}

export default PlanDisplay;
