import React, { useState, useEffect } from 'react';
import { UserProfile, Gender, ActivityLevel, Goal } from '../types';
import { ChevronRight, ChevronLeft, Activity, Target, Utensils, Ruler, Weight, User } from 'lucide-react';

interface OnboardingFormProps {
  onSubmit: (profile: UserProfile) => void;
  isLoading: boolean;
}

const STEPS = ['Basics', 'Stats', 'Lifestyle', 'Goals'];

const OnboardingForm: React.FC<OnboardingFormProps> = ({ onSubmit, isLoading }) => {
  // Load state from localStorage
  const [step, setStep] = useState(() => {
    if (typeof window !== 'undefined') {
        const saved = localStorage.getItem('fitgenius_form_step');
        return saved ? parseInt(saved) : 0;
    }
    return 0;
  });

  const [units, setUnits] = useState<'metric' | 'imperial'>(() => {
    if (typeof window !== 'undefined') {
        const saved = localStorage.getItem('fitgenius_form_units');
        return (saved === 'imperial' || saved === 'metric') ? saved : 'metric';
    }
    return 'metric';
  });
  
  const [profile, setProfile] = useState<Partial<UserProfile>>(() => {
    const defaultState = {
        gender: Gender.Male,
        activityLevel: ActivityLevel.ModeratelyActive,
        goal: Goal.BuildMuscle,
        equipment: 'Full Gym'
    };
    if (typeof window !== 'undefined') {
        const saved = localStorage.getItem('fitgenius_form_draft');
        try {
            return saved ? { ...defaultState, ...JSON.parse(saved) } : defaultState;
        } catch (e) {
            return defaultState;
        }
    }
    return defaultState;
  });

  // Persist state changes
  useEffect(() => {
    localStorage.setItem('fitgenius_form_step', step.toString());
  }, [step]);

  useEffect(() => {
    localStorage.setItem('fitgenius_form_units', units);
  }, [units]);

  useEffect(() => {
    localStorage.setItem('fitgenius_form_draft', JSON.stringify(profile));
  }, [profile]);

  const handleNext = () => setStep((prev) => Math.min(prev + 1, STEPS.length - 1));
  const handleBack = () => setStep((prev) => Math.max(prev - 1, 0));

  const handleFinish = () => {
    // Validate required fields
    if (profile.age && profile.height && profile.weight) {
        onSubmit(profile as UserProfile);
    } else {
        alert("Please fill in all numerical fields.");
    }
  };

  const updateField = (field: keyof UserProfile, value: any) => {
    setProfile(prev => ({ ...prev, [field]: value }));
  };

  // Helper functions for unit conversion
  const getFtIn = (cm: number | undefined) => {
    if (!cm) return { ft: '', in: '' };
    const totalInches = cm / 2.54;
    const ft = Math.floor(totalInches / 12);
    const inches = Math.round(totalInches % 12);
    // Handle rounding edge case (e.g. 5'11.9" rounding to 5'12")
    if (inches === 12) {
        return { ft: ft + 1, in: 0 };
    }
    return { ft, in: inches };
  };

  const getLbs = (kg: number | undefined) => {
      if (!kg && kg !== 0) return '';
      return Math.round(kg * 2.20462);
  };

  const handleImperialHeightChange = (type: 'ft' | 'in', value: string) => {
    const current = getFtIn(profile.height);
    const val = value === '' ? 0 : parseInt(value);
    if (isNaN(val)) return;
    
    // If updating feet, use new feet + current inches
    // If updating inches, use current feet + new inches
    let newFt = type === 'ft' ? val : (current.ft === '' ? 0 : current.ft);
    let newIn = type === 'in' ? val : (current.in === '' ? 0 : current.in);

    // Convert back to cm
    const totalInches = (Number(newFt) * 12) + Number(newIn);
    const cm = Math.round(totalInches * 2.54);
    updateField('height', cm);
  };

  const handleImperialWeightChange = (value: string) => {
      if (value === '') {
          updateField('weight', undefined);
          return;
      }
      const lbs = parseFloat(value);
      if (isNaN(lbs)) return;
      
      // Store precise kg to support integer lbs round-trip
      // We round to 2 decimals to keep the KG value clean but precise enough to distinguish integer Lbs
      const kg = parseFloat((lbs / 2.20462).toFixed(2));
      updateField('weight', kg);
  };

  return (
    <div className="max-w-2xl mx-auto px-4 py-8">
      {/* Progress Bar */}
      <div className="mb-8">
        <div className="flex justify-between mb-2">
            {STEPS.map((s, i) => (
                <span key={s} className={`text-xs font-semibold uppercase tracking-wider ${i <= step ? 'text-emerald-600' : 'text-slate-300'}`}>
                    {s}
                </span>
            ))}
        </div>
        <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
          <div 
            className="h-full bg-emerald-500 transition-all duration-500 ease-out"
            style={{ width: `${((step + 1) / STEPS.length) * 100}%` }}
          />
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-xl border border-slate-100 p-8 min-h-[400px] flex flex-col justify-between relative overflow-hidden">
        {/* Step Content */}
        <div className="animate-fade-in relative z-10">
          {step === 0 && (
            <div className="space-y-6">
              <h2 className="text-2xl font-bold text-slate-800 flex items-center gap-2">
                <User className="text-emerald-500" /> Let's get to know you
              </h2>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Gender</label>
                  <div className="grid grid-cols-3 gap-3">
                    {Object.values(Gender).map((g) => (
                      <button
                        key={g}
                        onClick={() => updateField('gender', g)}
                        className={`p-3 rounded-xl border text-sm font-medium transition-all ${
                          profile.gender === g
                            ? 'border-emerald-500 bg-emerald-50 text-emerald-700 ring-1 ring-emerald-500'
                            : 'border-slate-200 hover:border-emerald-300 hover:bg-slate-50 text-slate-600'
                        }`}
                      >
                        {g}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Age</label>
                    <input
                        type="number"
                        min="10"
                        max="100"
                        value={profile.age || ''}
                        onChange={(e) => updateField('age', parseInt(e.target.value))}
                        placeholder="Years"
                        className="w-full p-3 bg-transparent text-slate-800 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition-all"
                    />
                </div>
              </div>
            </div>
          )}

          {step === 1 && (
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold text-slate-800 flex items-center gap-2">
                    <Ruler className="text-emerald-500" /> Body Stats
                </h2>
                
                <div className="bg-slate-100 p-1 rounded-lg flex text-sm font-medium">
                    <button 
                        onClick={() => setUnits('metric')} 
                        className={`px-3 py-1 rounded-md transition-all ${units === 'metric' ? 'bg-white text-emerald-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
                    >
                        Metric
                    </button>
                    <button 
                        onClick={() => setUnits('imperial')} 
                        className={`px-3 py-1 rounded-md transition-all ${units === 'imperial' ? 'bg-white text-emerald-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
                    >
                        Imperial
                    </button>
                </div>
              </div>
              
              <div className="grid grid-cols-1 gap-6">
                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">
                        Height {units === 'metric' ? '(cm)' : '(ft / in)'}
                    </label>
                    
                    {units === 'metric' ? (
                        <div className="relative">
                            <input
                                type="number"
                                value={profile.height || ''}
                                onChange={(e) => updateField('height', parseInt(e.target.value))}
                                placeholder="e.g. 175"
                                className="w-full p-3 pl-10 bg-transparent text-slate-800 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
                            />
                            <Ruler className="w-5 h-5 text-slate-400 absolute left-3 top-3.5" />
                        </div>
                    ) : (
                        <div className="grid grid-cols-2 gap-3">
                            <div className="relative">
                                <input
                                    type="number"
                                    value={getFtIn(profile.height).ft}
                                    onChange={(e) => handleImperialHeightChange('ft', e.target.value)}
                                    placeholder="Ft"
                                    className="w-full p-3 pl-10 bg-transparent text-slate-800 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
                                />
                                <span className="absolute left-3 top-3.5 text-slate-400 text-sm font-bold">ft</span>
                            </div>
                            <div className="relative">
                                <input
                                    type="number"
                                    value={getFtIn(profile.height).in}
                                    onChange={(e) => handleImperialHeightChange('in', e.target.value)}
                                    placeholder="In"
                                    className="w-full p-3 pl-10 bg-transparent text-slate-800 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
                                />
                                <span className="absolute left-3 top-3.5 text-slate-400 text-sm font-bold">in</span>
                            </div>
                        </div>
                    )}
                </div>

                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">
                        Weight {units === 'metric' ? '(kg)' : '(lbs)'}
                    </label>
                    <div className="relative">
                        {units === 'metric' ? (
                            <input
                                type="number"
                                value={profile.weight || ''}
                                onChange={(e) => updateField('weight', parseFloat(e.target.value))}
                                placeholder="e.g. 70"
                                className="w-full p-3 pl-10 bg-transparent text-slate-800 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
                            />
                        ) : (
                            <input
                                type="number"
                                value={getLbs(profile.weight)}
                                onChange={(e) => handleImperialWeightChange(e.target.value)}
                                placeholder="e.g. 150"
                                className="w-full p-3 pl-10 bg-transparent text-slate-800 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
                            />
                        )}
                        <Weight className="w-5 h-5 text-slate-400 absolute left-3 top-3.5" />
                    </div>
                </div>
              </div>
            </div>
          )}

          {step === 2 && (
             <div className="space-y-6">
                <h2 className="text-2xl font-bold text-slate-800 flex items-center gap-2">
                    <Activity className="text-emerald-500" /> Lifestyle & Equipment
                </h2>

                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Activity Level</label>
                    <select 
                        className="w-full p-3 bg-transparent text-slate-800 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500"
                        value={profile.activityLevel}
                        onChange={(e) => updateField('activityLevel', e.target.value as ActivityLevel)}
                    >
                        {Object.values(ActivityLevel).map(level => (
                            <option key={level} value={level}>{level}</option>
                        ))}
                    </select>
                </div>

                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Equipment Available</label>
                    <div className="grid grid-cols-2 gap-3">
                        {['Bodyweight Only', 'Dumbbells Only', 'Basic Home Gym', 'Full Gym'].map(eq => (
                            <button
                                key={eq}
                                onClick={() => updateField('equipment', eq)}
                                className={`p-3 text-sm rounded-xl border text-left transition-all ${
                                    profile.equipment === eq
                                    ? 'border-emerald-500 bg-emerald-50 text-emerald-700 ring-1 ring-emerald-500'
                                    : 'border-slate-200 hover:bg-slate-50'
                                }`}
                            >
                                {eq}
                            </button>
                        ))}
                    </div>
                </div>
             </div>
          )}

          {step === 3 && (
            <div className="space-y-6">
                <h2 className="text-2xl font-bold text-slate-800 flex items-center gap-2">
                    <Target className="text-emerald-500" /> Goals & Diet
                </h2>

                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Primary Goal</label>
                    <select 
                        className="w-full p-3 bg-transparent text-slate-800 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500"
                        value={profile.goal}
                        onChange={(e) => updateField('goal', e.target.value as Goal)}
                    >
                        {Object.values(Goal).map(g => (
                            <option key={g} value={g}>{g}</option>
                        ))}
                    </select>
                </div>

                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Dietary Restrictions (Optional)</label>
                    <div className="relative">
                        <input
                            type="text"
                            value={profile.dietaryRestrictions || ''}
                            onChange={(e) => updateField('dietaryRestrictions', e.target.value)}
                            placeholder="e.g. Vegetarian, No Dairy, Keto..."
                            className="w-full p-3 pl-10 bg-transparent text-slate-800 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
                        />
                        <Utensils className="w-5 h-5 text-slate-400 absolute left-3 top-3.5" />
                    </div>
                </div>
            </div>
          )}
        </div>

        {/* Navigation */}
        <div className="flex justify-between mt-8 pt-6 border-t border-slate-100 z-10">
            <button
                onClick={handleBack}
                disabled={step === 0 || isLoading}
                className={`flex items-center gap-1 px-4 py-2 rounded-lg font-medium transition-colors ${
                    step === 0 ? 'text-slate-300 cursor-not-allowed' : 'text-slate-600 hover:bg-slate-100'
                }`}
            >
                <ChevronLeft className="w-4 h-4" /> Back
            </button>

            {step === STEPS.length - 1 ? (
                <button
                    onClick={handleFinish}
                    disabled={isLoading}
                    className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white px-8 py-3 rounded-xl font-bold shadow-lg shadow-emerald-200 transition-all hover:scale-105 active:scale-95 disabled:opacity-70 disabled:cursor-not-allowed"
                >
                    {isLoading ? 'Generating Plan...' : 'Create My Plan'}
                    {!isLoading && <Target className="w-4 h-4" />}
                </button>
            ) : (
                <button
                    onClick={handleNext}
                    className="flex items-center gap-2 bg-slate-900 hover:bg-slate-800 text-white px-6 py-3 rounded-xl font-medium transition-all hover:translate-x-1"
                >
                    Next <ChevronRight className="w-4 h-4" />
                </button>
            )}
        </div>
      </div>
    </div>
  );
};

export default OnboardingForm;