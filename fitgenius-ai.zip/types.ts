export enum Gender {
  Male = 'Male',
  Female = 'Female',
  Other = 'Other'
}

export enum ActivityLevel {
  Sedentary = 'Sedentary (Office job)',
  LightlyActive = 'Lightly Active (1-2 days/week)',
  ModeratelyActive = 'Moderately Active (3-5 days/week)',
  VeryActive = 'Very Active (6-7 days/week)',
  ExtraActive = 'Extra Active (Physical job or 2x training)'
}

export enum Goal {
  LoseWeight = 'Lose Weight',
  BuildMuscle = 'Build Muscle',
  ImproveEndurance = 'Improve Endurance',
  Maintain = 'Maintain Health',
  Flexibility = 'Increase Flexibility'
}

export interface UserProfile {
  age: number;
  gender: Gender;
  height: number; // cm
  weight: number; // kg
  activityLevel: ActivityLevel;
  goal: Goal;
  dietaryRestrictions: string;
  equipment: string; // e.g., "Full Gym", "Dumbbells only", "Bodyweight"
}

export interface Exercise {
  name: string;
  sets: number;
  reps: string;
  notes: string;
}

export interface WorkoutDay {
  dayName: string; // e.g., "Day 1 - Push"
  focus: string;
  exercises: Exercise[];
  durationMinutes: number;
}

export interface Meal {
  type: string; // Breakfast, Lunch, Dinner, Snack
  name: string;
  calories: number;
  protein: number; // g
  carbs: number; // g
  fats: number; // g
  ingredients: string[];
}

export interface DietDay {
  dayName: string;
  totalCalories: number;
  meals: Meal[];
}

export interface FitnessPlan {
  overview: string;
  weeklySchedule: WorkoutDay[];
  nutritionPlan: DietDay[]; // Simplified to 1 representative day or multiple
  tips: string[];
}
